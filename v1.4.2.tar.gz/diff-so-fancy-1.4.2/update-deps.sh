#!/bin/bash

# initalize the bats components
git submodule sync && git submodule update --init
